import UIKit

var lado1: Double = 2
var lado2: Double = 7
var lado3: Double = 6

if lado1 == lado2 && lado1 == lado3 {
    print("Es un triángulo equilátero")
}
if lado1 != lado2 && lado1 != lado3 && lado2 != lado3{
    print("triángulo escaleno")
}
if (lado1 != lado2 && lado1 != lado3 && lado2 == lado3) || (lado2 != lado1 && lado2 != lado3 && lado1 == lado3) || lado3 != lado2 && lado3 != lado1 && lado1 == lado2 {
    print("triángulo isóseles")
}


